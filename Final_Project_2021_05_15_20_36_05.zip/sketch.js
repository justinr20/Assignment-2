var img;
var song;

function preload(){
  img = loadImage("Copcar.png");
  
}

function setup() {
  createCanvas(400, 400)
  song = loadSound("siren.mp3",loaded);
}

function loaded(){
  song.play();
 

}

var i = 0


function draw() { 
  
 
  

 i = i + 1
  

  if (i % 10 === 0){
    
  	fill(50);
    rect(86,50,70,50);
  } else {

    fill(250, 9, 9);
    rect(86,50,70,50);
  }




 

  

  if (i % 10 === 0){
    fill(50);
    rect(240,50,70,50);
  } else {
   
    fill(0, 62, 254);
    rect(240,50,70,50);
    fill(147,150,156);
    rect(158,50,80,50);
  }
  
 
  
    image(img,0,100,400,300);
  
  
}
  
